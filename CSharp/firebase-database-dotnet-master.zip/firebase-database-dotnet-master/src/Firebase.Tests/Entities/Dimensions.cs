﻿namespace Firebase.Database.Tests.Entities
{
    public class Dimensions
    {
        public double Height { get; set; }

        public double Length { get; set; }

        public double Weight { get; set; }
    }
}
