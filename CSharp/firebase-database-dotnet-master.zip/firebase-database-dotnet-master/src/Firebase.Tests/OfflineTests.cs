﻿namespace Firebase.Database.Tests
{
    using Firebase.Database.Tests.Entities;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class OfflineTests
    {
        public const string BasePath = "http://base.path.net";

        [TestMethod]
        public void Test()
        {
            
        }
    }
}
