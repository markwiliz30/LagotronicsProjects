namespace Firebase.Dinosaurs
{
    public class Dinosaur
    {
        public double Height { get; set; }
    }
}
