﻿This is a very simple console chat showing how you can subscribe to a location and post to it. All you need to do is specify your own firebase instance.

Run the Console twice (or more times) - it's a chat after all.